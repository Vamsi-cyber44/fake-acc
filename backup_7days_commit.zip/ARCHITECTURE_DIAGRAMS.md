# System Architecture & Data Flow Diagrams

## 🏗️ Overall System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    FAKE ACCOUNT DETECTOR                         │
└─────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────┐    ┌──────────────────────────┐
│      FRONTEND (React)            │    │    BACKEND (Node.js)     │
│   http://localhost:3000          │    │  http://localhost:8000   │
├──────────────────────────────────┤    ├──────────────────────────┤
│                                  │    │                          │
│  Components:                     │    │  API Routes:             │
│  ├─ App.tsx (Auth Check)        │◄──►├─ /api/auth/*            │
│  ├─ AuthModal.tsx              │    ├─ /api/users/*           │
│  ├─ Dashboard.tsx              │    │                          │
│  ├─ SettingsView.tsx           │    │  Services:               │
│  ├─ HistoryView.tsx            │    ├─ Authentication          │
│  └─ ...others                  │    ├─ Password Hashing        │
│                                  │    ├─ Email Validation       │
│  Services:                       │    │                          │
│  ├─ authService.ts             │    │  Database:               │
│  ├─ api.ts                     │    ├─ MongoDB                 │
│  └─ ...other services          │    │                          │
│                                  │    │  Middleware:             │
│  State:                          │    ├─ JWT Verification       │
│  ├─ Auth (localStorage)         │    ├─ CORS Protection        │
│  ├─ User Data                  │    ├─ Rate Limiting          │
│  └─ Preferences                │    └─ Error Handling         │
│                                  │                              │
└──────────────────────────────────┘    └──────────────────────────┘
              ▲                                      │
              │                                      │
              │ HTTP/JSON Requests                  │
              │ JWT Token in Headers                │
              │                                      ▼
              └──────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│                      MONGODB DATABASE                            │
│                 (Users, Preferences, History)                    │
└──────────────────────────────────────────────────────────────────┘
```

---

## 🔐 Authentication Flow

```
┌─────────────┐
│    User     │
└──────┬──────┘
       │
       │ 1. Enter email/password
       ▼
┌──────────────────────────┐
│   Frontend (AuthModal)   │
│  email: john@example.com │
│  password: SecurePass123 │
└──────────┬───────────────┘
           │
           │ 2. HTTP POST /api/auth/login
           ▼
┌──────────────────────────────┐
│  Backend (auth.controller)   │
│ 1. Find user by email        │
│ 2. Verify password (bcrypt)  │
│ 3. Generate JWT tokens       │
│ 4. Return tokens + user data │
└──────────┬───────────────────┘
           │
           │ 3. Response:
           │ {
           │   "tokens": {
           │     "accessToken": "eyJhbGc...",
           │     "refreshToken": "eyJhbGc..."
           │   },
           │   "user": { ... }
           │ }
           ▼
┌──────────────────────────────┐
│   Frontend (authService)     │
│ 1. Store accessToken         │
│ 2. Store refreshToken        │
│ 3. Store user data           │
│ 4. Update auth state         │
└──────────┬───────────────────┘
           │
           │ 4. Redirect to Dashboard
           ▼
┌──────────────────────────────┐
│   User Logged In             │
│   Accessing Dashboard        │
└──────────────────────────────┘
```

---

## 📱 API Request Flow

```
┌─────────────────────────────────────────────────────────────┐
│              React Component (e.g., SettingsView)           │
│  useEffect(() => {                                          │
│    const profile = await authService.getProfile()          │
│  })                                                         │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
         ┌─────────────────────────────┐
         │   authService.ts            │
         │  (axios interceptor)        │
         │ 1. Add Auth header          │
         │ 2. Add token to request     │
         │ 3. Make HTTP call           │
         └──────────┬──────────────────┘
                    │
                    │ GET /api/users/profile
                    │ Authorization: Bearer <token>
                    ▼
         ┌─────────────────────────────┐
         │   Backend API               │
         │ 1. Verify JWT token         │
         │ 2. Find user in DB          │
         │ 3. Return user data         │
         └──────────┬──────────────────┘
                    │
                    │ Response:
                    │ {
                    │   "user": {
                    │     "email": "john@example.com",
                    │     "username": "john_doe",
                    │     ...
                    │   }
                    │ }
                    ▼
         ┌─────────────────────────────┐
         │   axios Response            │
         │ 1. Check status code        │
         │ 2. If 401: refresh token    │
         │ 3. Return data to component │
         └──────────┬──────────────────┘
                    │
                    ▼
         ┌─────────────────────────────┐
         │  React Component            │
         │  Display user data          │
         │  <p>{profile.user.email}</p>│
         └─────────────────────────────┘
```

---

## 🔄 Token Refresh Flow

```
┌────────────────────────┐
│  API Request with      │
│  Expired Token         │
└─────────────┬──────────┘
              │
              ▼
    ┌─────────────────────┐
    │  Backend Response   │
    │  Status: 401        │
    │  (Unauthorized)     │
    └─────────┬───────────┘
              │
              ▼
    ┌─────────────────────────┐
    │  axios Error Handler    │
    │  Interceptor            │
    │ 1. Check if 401         │
    │ 2. Get refreshToken     │
    │ 3. POST /refresh-token  │
    └─────────┬───────────────┘
              │
              ▼
    ┌─────────────────────────┐
    │  Backend Refresh        │
    │  1. Verify refreshToken │
    │  2. Generate new token  │
    │  3. Return new token    │
    └─────────┬───────────────┘
              │
              ▼
    ┌─────────────────────────┐
    │  Frontend              │
    │  1. Store new token     │
    │  2. Retry original req  │
    │  3. Add new token       │
    └─────────┬───────────────┘
              │
              ▼
    ┌─────────────────────────┐
    │  Backend Process Req    │
    │  With new token         │
    │  Status: 200 (Success)  │
    └─────────┬───────────────┘
              │
              ▼
    ┌─────────────────────────┐
    │  Frontend Receives Data │
    │  Operation succeeds     │
    │  User doesn't notice    │
    └─────────────────────────┘
```

---

## 📊 Data Flow: User Profile Update

```
User Interface
    │
    │ User edits name field
    │ and clicks "Save"
    ▼
┌─────────────────────────────┐
│  SettingsView Component     │
│  handleSaveProfile()        │
└──────────┬──────────────────┘
           │
           │ Call API
           ▼
┌─────────────────────────────┐
│  authService.updateProfile()│
│  PUT /api/users/profile     │
│  { username: "new_name" }   │
└──────────┬──────────────────┘
           │
           │ With Token
           ▼
┌─────────────────────────────┐
│  Backend API                │
│  user.controller.ts         │
│ 1. Verify token             │
│ 2. Update user in DB        │
│ 3. Return success           │
└──────────┬──────────────────┘
           │
           │ Response
           ▼
┌─────────────────────────────┐
│  Frontend                   │
│  1. Update state            │
│  2. Show success message    │
│  3. Reflect changes in UI   │
└─────────────────────────────┘
```

---

## 🔐 Password Reset Flow

```
┌──────────────────────┐
│  User Forgot         │
│  Password            │
└──────────┬───────────┘
           │
           │ 1. Click "Forgot Password"
           ▼
┌────────────────────────────────┐
│  Frontend Form                 │
│  Enter email: john@example.com │
└──────────┬─────────────────────┘
           │
           │ POST /api/auth/forgot-password
           ▼
┌────────────────────────────────┐
│  Backend Process               │
│  1. Find user by email         │
│  2. Generate reset token       │
│  3. Save token to DB (exp 1h)  │
│  4. Send email with token      │
│  5. Return success             │
└──────────┬─────────────────────┘
           │
           │ User receives email
           │ with reset link
           ▼
┌────────────────────────────────┐
│  User Clicks Email Link        │
│  Includes reset token in URL   │
│  http://localhost:3000/reset?  │
│  token=eyJhbGc...             │
└──────────┬─────────────────────┘
           │
           │ 2. Frontend verifies token
           │ 3. Shows password reset form
           ▼
┌────────────────────────────────┐
│  User Enters New Password      │
│  Confirm Password: SecurePass123
└──────────┬─────────────────────┘
           │
           │ POST /api/auth/reset-password
           │ { token, newPassword, ... }
           ▼
┌────────────────────────────────┐
│  Backend Process               │
│  1. Verify reset token         │
│  2. Hash new password          │
│  3. Update in DB               │
│  4. Invalidate old token       │
│  5. Return success             │
└──────────┬─────────────────────┘
           │
           │ Success!
           ▼
┌────────────────────────────────┐
│  User Can Now Login            │
│  With New Password             │
└────────────────────────────────┘
```

---

## 📈 Scan History Flow

```
┌────────────────────────────────┐
│  User Views History Tab        │
└──────────┬─────────────────────┘
           │
           │ useEffect hook
           ▼
┌────────────────────────────────┐
│  authService.getScanHistory()  │
│  GET /api/users/scan-history   │
│  params: { limit: 12, skip: 0 }│
│  Headers: Authorization: Bearer │
└──────────┬─────────────────────┘
           │
           ▼
┌────────────────────────────────┐
│  Backend API                   │
│  1. Verify JWT token           │
│  2. Find user by token         │
│  3. Query MongoDB:             │
│     scanHistory collection     │
│     Sort by date DESC          │
│     Limit 12, skip 0           │
│  4. Return array of scans      │
└──────────┬─────────────────────┘
           │
           │ Response:
           │ {
           │   "history": [
           │     {
           │       "id": "scan123",
           │       "platform": "instagram",
           │       "targetUsername": "example_user",
           │       "riskScore": 75,
           │       "verdict": "SUSPICIOUS",
           │       "scannedAt": "2026-01-30T10:30:00Z"
           │     },
           │     ...more scans
           │   ]
           │ }
           ▼
┌────────────────────────────────┐
│  Frontend                      │
│  1. Set loading state          │
│  2. Store history data         │
│  3. Render scan cards          │
│  4. Show filters (platform)    │
│  5. Show pagination            │
└──────────┬─────────────────────┘
           │
           │ User can:
           │ - Filter by platform
           │ - View scan details
           │ - Click to expand
           │ - Paginate results
           ▼
┌────────────────────────────────┐
│  Display Scan Details          │
│  ├─ Risk Score: 75%            │
│  ├─ Platform: Instagram        │
│  ├─ Verdict: SUSPICIOUS        │
│  ├─ Scanned: 1/30/2026         │
│  └─ Breakdown: [modules...]    │
└────────────────────────────────┘
```

---

## 🛡️ Security Layers

```
┌─────────────────────────────────────────────────────────┐
│  HTTP Request                                           │
└───────────────┬─────────────────────────────────────────┘
                │
                ▼
    ┌──────────────────────────┐
    │ CORS Check               │
    │ Origin: localhost:3000   │
    │ Allowed? YES → Continue  │
    │           NO  → Reject   │
    └─────────┬────────────────┘
              │
              ▼
    ┌──────────────────────────┐
    │ Rate Limiting            │
    │ 100 req/15 min per IP    │
    │ Over limit? Block        │
    └─────────┬────────────────┘
              │
              ▼
    ┌──────────────────────────┐
    │ JWT Verification         │
    │ 1. Extract token         │
    │ 2. Verify signature      │
    │ 3. Check expiration      │
    │ 4. Check user exists     │
    └─────────┬────────────────┘
              │
              ▼
    ┌──────────────────────────┐
    │ Input Validation         │
    │ Joi schemas validate     │
    │ Type checking            │
    │ Format validation        │
    └─────────┬────────────────┘
              │
              ▼
    ┌──────────────────────────┐
    │ Authorization Check      │
    │ User role: Admin/User    │
    │ Has permission?          │
    └─────────┬────────────────┘
              │
              ▼
    ┌──────────────────────────┐
    │ Database Operation       │
    │ Query/Insert/Update      │
    │ Mongoose validation      │
    └─────────┬────────────────┘
              │
              ▼
    ┌──────────────────────────┐
    │ Response                 │
    │ ✅ Success/Error         │
    │ No sensitive data leak   │
    └──────────────────────────┘
```

---

## 📊 State Management

```
React Component
    │
    │ Updates triggered by:
    │ 1. User interaction
    │ 2. API response
    │ 3. Time-based (polling)
    │ 4. URL change
    ▼

┌─────────────────────────────────────┐
│  Local State (useState)             │
│  ├─ formData                        │
│  ├─ loading                         │
│  ├─ error                           │
│  └─ userData                        │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│  Browser Storage (localStorage)     │
│  ├─ accessToken                     │
│  ├─ refreshToken                    │
│  ├─ user (JSON)                     │
│  └─ settings (JSON)                 │
└─────────────────────────────────────┘

┌─────────────────────────────────────┐
│  Backend Database (MongoDB)         │
│  ├─ User collection                 │
│  ├─ Preferences collection          │
│  ├─ ScanHistory collection          │
│  └─ RefreshTokens collection        │
└─────────────────────────────────────┘

Component Lifecycle:
1. Mount → Check localStorage
2. Load → Fetch from backend
3. Update → Save to backend
4. Unload → Cleanup tokens
```

---

## 🎯 Summary

This architecture provides:
- ✅ **Separation of Concerns**: Frontend & Backend independent
- ✅ **Security**: JWT, CORS, Rate Limiting, Input Validation
- ✅ **Scalability**: Stateless API, DB-backed state
- ✅ **Resilience**: Error handling, fallbacks, retries
- ✅ **Performance**: Token caching, API optimization
- ✅ **Maintainability**: Clean code structure, TypeScript types

---

**Architecture Version**: 1.0
**Last Updated**: January 30, 2026
